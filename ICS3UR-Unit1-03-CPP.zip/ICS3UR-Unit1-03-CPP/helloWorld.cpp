// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Nov 2020
// This is the "Hello, World" program, but with nice style

#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
}
